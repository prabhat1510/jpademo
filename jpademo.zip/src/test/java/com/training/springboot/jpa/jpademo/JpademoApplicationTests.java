package com.training.springboot.jpa.jpademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
