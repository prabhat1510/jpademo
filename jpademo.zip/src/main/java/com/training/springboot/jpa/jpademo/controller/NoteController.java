/**
 * 
 */
package com.training.springboot.jpa.jpademo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.springboot.jpa.jpademo.model.Note;
import com.training.springboot.jpa.jpademo.service.INoteService;

/**
 * @author admi
 *
 */
@RestController
@RequestMapping("/api")
public class NoteController {
	@Autowired
	INoteService noteService;
	
	//Get ALL Notes
	@GetMapping("/notes")
	//@RequestMapping(value="/notes",method=RequestMethod.GET)
	public List<Note> getAllNotes(){
		return noteService.getAllNotes();
	}
	//Create  a new Note
	@PostMapping("/notes")
	public Note createNote(@RequestBody Note note) {
		return noteService.createNote(note);
	}
	//Get a Single Note
	//Update a Note
	//Delete a Note
}
